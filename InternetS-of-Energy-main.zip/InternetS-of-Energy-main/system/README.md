CitizenWatt System scripts
==========================

Launch these two scripts as root, with bash :
- sudo bash install_python34.sh
- sudo bash cleanup_raspbian.sh (removes Gnome UI)


* citizenwatt.sh is a Debian service to add to startup in /etc/init.d
