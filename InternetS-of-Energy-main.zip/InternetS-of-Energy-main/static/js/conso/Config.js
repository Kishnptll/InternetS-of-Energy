// General params
var Config = {
	update_timeout: 2000, // Milliseconds
	rect_width: 12, // Pixels
	rect_margin: 2, // Pixels
	timestep: 8 // Second
};
